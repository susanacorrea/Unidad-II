from setuptools import setup
setup(
    name='compras',
    version='1.0',
    description='Modulo de formulas de contaduria',
    author='susana',
    author_email='susymares@gmail.com',
    url='www.utng.edu.mx',
    py_modules=['compras'],
)